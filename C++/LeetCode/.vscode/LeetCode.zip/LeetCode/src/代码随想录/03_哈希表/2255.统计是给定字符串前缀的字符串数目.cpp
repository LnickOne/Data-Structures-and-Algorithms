/*
给你一个字符串数组 words 和一个字符串 s ，其中 words[i] 和 s 只包含 小写英文字母 。

请你返回 words 中是字符串 s 前缀 的 字符串数目 。

一个字符串的 前缀 是出现在字符串开头的子字符串。子字符串 是一个字符串中的连续一段字符序列。
示例 1：
输入：words = ["a","b","c","ab","bc","abc"], s = "abc"
输出：3
解释：
words 中是 s = "abc" 前缀的字符串为：
"a" ，"ab" 和 "abc" 。
所以 words 中是字符串 s 前缀的字符串数目为 3 。
示例 2：

输入：words = ["a","a"], s = "aa"
输出：2
解释：
两个字符串都是 s 的前缀。
注意，相同的字符串可能在 words 中出现多次，它们应该被计数多次。
*/
#include "../../include/utils.h"
class Solution
{
public:
    int countPrefixes(vector<string> &words, string s)
    {
        if (words.empty())
            return 0;
        unordered_map<string, int> strMap;
        string path;
        for (char &c : s)
        {
            string ch(1, c);
            path += ch;
            strMap[path] = 1;
        }
        int count = 0;
        for (string &str : words)
            if (strMap[str] > 0)
                ++count;
        return count;
    }
};
int main() {
    vector<string> words = {"a","b","c","ab","bc","abc"};
    string s = "abc";
    Solution s1;
    int result = s1.countPrefixes(words, s);
    cout << result << endl;
    return 0;
}