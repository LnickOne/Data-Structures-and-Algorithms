#include <vector>
#include <iostream>
#include <algorithm>
#include <climits>
using namespace std;
/*
给你一个由 不同 整数组成的数组 nums ，和一个目标整数 target 。
请你从 nums 中找出并返回总和为 target 的元素组合的个数。
题目数据保证答案符合 32 位整数范围。
示例 1：
输入：nums = [1,2,3], target = 4
输出：7
解释：
所有可能的组合为：
(1, 1, 1, 1)
(1, 1, 2)
(1, 2, 1)
(1, 3)
(2, 1, 1)
(2, 2)
(3, 1)
请注意，顺序不同的序列被视作不同的组合,其实是在求排列。
示例 2：
输入：nums = [9], target = 3
输出：0
*/
class Solution
{
public:
    int combinationSum4(vector<int> &nums, int target)
    {
        // 虽然题目说是组合，但其实是说不同的排列，因此在需要先遍历背包，再遍历物品
        int backpack_capacity = target;
        vector<int> dp(backpack_capacity + 1, 0);
        dp[0] = 1;
        for (int j = 0; j <= backpack_capacity; j++) // 遍历背包，如果先遍历背包，就要从0开始
        {
            for (int i = 0; i < nums.size(); i++) // 遍历物品
            {
                if (j - nums[i] >= 0 && dp[j] < INT_MAX - dp[j - nums[i]])
                {
                    dp[j] += dp[j - nums[i]];
                }
            }
        }
        return dp[target];
    }
};

int main()
{
    vector<int> nums = {1, 2, 3};
    int target = 4;
    Solution s;
    cout << s.combinationSum4(nums, target);
    cout << endl;
   
    return 0;
}