/*
完全背包的核心思想
遍历背包容量的顺序使用正序遍历,不使用倒序,从而可以让物品使用多次。
并且完全背包一维dp数组的两个for遍历的先后循序是可以颠倒。
先遍历物品再遍历背包得到的是组合数，先遍历背包再遍历物品得到的是排列数，根据题意灵活变通
for (int i = 0; i < weight.size(), i++)                  // 遍历物品
    for (int j = weight[i]; j <= backpack_capacity; j++) // 遍历背包容量,后遍历背包从物品的重量开始,求组合数
        dp[j] = max(dp[j], dp[j - weight[i]] + value[i]);

for (int j = 0; j <= backpack_capacity; j++) // 遍历背包容量,先遍历背包从0开始，求排列数
    for (int i = 0; i < weight.size(); i++) // 遍历物品,因为背包容量是0了,所以物品也可以从0开始,但其实指的是第一个物品的重量
        if (j - weight[i] >= 0) // 并且要加上判断语句是否能装上物品
            dp[j] = max(dp[j], dp[j - weight[i]] + value[i]);

在完全背包中，对于一维dp数组如果求的是背包能装的最大价值，两个for循环嵌套顺序是可以颠倒的
*/
