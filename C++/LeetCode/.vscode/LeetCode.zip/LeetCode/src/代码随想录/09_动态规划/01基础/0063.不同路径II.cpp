/*
给定一个 m x n 的整数数组 grid。
一个机器人初始位于 左上角（即 grid[0][0]）。
机器人尝试移动到 右下角（即 grid[m - 1][n - 1]）。机器人每次只能向下或者向右移动一步。
网格中的障碍物和空位置分别用 1 和 0 来表示。机器人的移动路径中不能包含 任何 有障碍物的方格。
返回机器人能够到达右下角的不同路径数量。
测试用例保证答案小于等于 2 * 109。
示例 1：
输入：obstacleGrid = [[0,0,0],[0,1,0],[0,0,0]]
输出：2
解释：3x3 网格的正中间有一个障碍物。
从左上角到右下角一共有 2 条不同的路径：
1. 向右 -> 向右 -> 向下 -> 向下
2. 向下 -> 向下 -> 向右 -> 向右
示例 2：
输入：obstacleGrid = [[0,1],[0,0]]
输出：1
*/
#include <vector>
#include <iostream>
using namespace std;
class Solution
{
public:
    int uniquePathsWithObstacles(vector<vector<int>> &obstacleGrid)
    {
        int n = obstacleGrid.size();
        vector<vector<int>> dp(n, vector<int>(obstacleGrid[0].size()));
        for (int i = 0; i < n; i++)
        {
            if (obstacleGrid[i][0] == 1) // 一旦遇到obstacleGrid[i][0] == 1的情况就停止dp[i][0]的赋值1的初始化操作
                break;
            dp[i][0] = 1;
        }
        for (int i = 0; i < obstacleGrid[0].size(); i++)
        {
            if (obstacleGrid[0][i] == 1) // 一旦遇到obstacleGrid[i][0] == 1的情况就停止dp[i][0]的赋值1的初始化操作
                break;
            dp[0][i] = 1;
        }
        for (int i = 1; i < n; i++)
        {
            for (int j = 1; j < obstacleGrid[0].size(); j++)
            {
                if (obstacleGrid[i][j] == 1)
                    continue;
                dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
            }
        }
        return dp[obstacleGrid.size() - 1][obstacleGrid[0].size() - 1];
    }
};

int main()
{
    Solution s;
    vector<vector<int>> obstacleGrid = {{0, 0, 0}, {0, 1, 0}, {0, 0, 0}};
    cout << s.uniquePathsWithObstacles(obstacleGrid) << endl;
    return 0;
}
