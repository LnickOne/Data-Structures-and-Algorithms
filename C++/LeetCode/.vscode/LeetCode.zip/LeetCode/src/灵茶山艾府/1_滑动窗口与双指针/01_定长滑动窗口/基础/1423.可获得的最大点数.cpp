/*
几张卡牌 排成一行，每张卡牌都有一个对应的点数。点数由整数数组 cardPoints 给出。
每次行动，你可以从行的开头或者末尾拿一张卡牌，最终你必须正好拿 k 张卡牌。
你的点数就是你拿到手中的所有卡牌的点数之和。
给你一个整数数组 cardPoints 和整数 k，请你返回可以获得的最大点数。

示例 1：
输入：cardPoints = [1,2,3,4,5,6,1], k = 3
输出：12
解释：第一次行动，不管拿哪张牌，你的点数总是 1。但是，先拿最右边的卡牌将会最大化你的可获得点数。
最优策略是拿右边的三张牌，最终点数为 1 + 6 + 5 = 12 。

示例 2：
输入：cardPoints = [2,2,2], k = 2
输出：4
解释：无论你拿起哪两张卡牌，可获得的点数总是 4 。

示例 3：
输入：cardPoints = [9,7,7,9,7,7,9], k = 7
输出：55
解释：你必须拿起所有卡牌，可以获得的点数为所有卡牌的点数之和。

示例 4：
输入：cardPoints = [1,1000,1], k = 1
输出：1
解释：你无法拿到中间那张卡牌，所以可以获得的最大点数为 1 。

示例 5：
输入：cardPoints = [1,79,80,1,1,1,200,1], k = 3
输出：202
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;
class Solution
{
public:
    int maxScore(vector<int> &cardPoints, int k)
    {
        if (cardPoints.empty() || k == 0) // 如果卡牌数组为空或者选取的卡牌数量为 0，直接返回 0
        {
            return 0;
        }
        if (cardPoints.size() == k) // 如果需要选取的卡牌数量等于卡牌数组的长度，直接返回所有卡牌点数之和
        {
            return accumulate(cardPoints.begin(), cardPoints.end(), 0);
        }
        int sum = accumulate(cardPoints.begin(), cardPoints.end(), 0); // 计算所有卡牌的点数总和
        int k_ = cardPoints.size() - k;                                // 计算滑动窗口的大小，即不选取的卡牌数量
        int total = 0;                                                 // 初始化滑动窗口内的卡牌点数之和
        for (int i = 0; i < k_; i += 1)                                // 计算第一个滑动窗口内的卡牌点数之和
        {
            total += cardPoints[i];
        }
        int minWindowSum = total; // 初始化最小的滑动窗口点数之和为当前窗口的点数之和
        for (int i = k_; i < cardPoints.size(); i += 1)
        {                                            // 滑动窗口，更新窗口内的点数之和，并记录最小的窗口点数之和
            total += cardPoints[i];                  // 加入新进入窗口的卡牌点数
            total -= cardPoints[i - k_];             // 移除离开窗口的卡牌点数
            minWindowSum = min(minWindowSum, total); // 更新最小的窗口点数之和
        }
        return sum - minWindowSum; // 用所有卡牌的点数总和减去最小的窗口点数之和，得到选取 k 张卡牌能获得的最大点数
    }
};
int main()
{
    vector<int> cardPoints = {1, 2, 3, 4, 5, 6, 1};
    int k = 3;
    Solution s;
    cout << s.maxScore(cardPoints, k) << endl;
    cardPoints = {2, 2, 2};
    k = 2;
    cout << s.maxScore(cardPoints, k) << endl;
    cardPoints = {9, 7, 7, 9, 7, 7, 9};
    k = 7;
    cout << s.maxScore(cardPoints, k) << endl;
    return 0;
}