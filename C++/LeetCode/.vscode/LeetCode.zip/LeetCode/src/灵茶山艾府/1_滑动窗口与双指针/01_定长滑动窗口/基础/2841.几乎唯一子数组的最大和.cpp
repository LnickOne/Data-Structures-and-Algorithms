/*
给你一个整数数组 nums 和两个正整数 m 和 k 。
请你返回 nums 中长度为 k 的 几乎唯一 子数组的 最大和。
如果不存在几乎唯一子数组，请你返回 0 。如果 nums 的一个子数组有至少
m个互不相同的元素，我们称它是 几乎唯一 子数组。
子数组指的是一个数组中一段连续非空 的元素序列。

示例 1：
输入：nums = [2,6,7,3,1,7], m = 3, k = 4
输出：18
解释：总共有 3 个长度为 k = 4 的几乎唯一子数组。分别为 [2, 6, 7, 3] ，[6, 7,
3,1] 和 [7, 3, 1, 7] 。 这些子数组中，和最大的是 [2, 6, 7, 3] ，和为 18 。

示例 2：
输入：nums = [5,9,9,2,4,5,4], m = 1, k = 3
输出：23
解释：总共有 5 个长度为 k = 3 的几乎唯一子数组。
分别为 [5, 9, 9] ，[9, 9, 2] ，[9, 2, 4] ，[2, 4, 5] 和 [4, 5, 4] 。
这些子数组中，和最大的是 [5, 9, 9] ，和为 23 。

示例 3：
输入：nums = [1,2,1,2,1,2,1], m = 3, k = 3
输出：0
解释：输入数组中不存在长度为 k = 3 的子数组含有至少  m = 3
个互不相同元素的子数组。所以不存在几乎唯一子数组，最大和为 0 。
*/
#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
  long maxSum(vector<int> &nums, int m, int k)
  {
    if (nums.size() < k)
      return 0;
    long sum = 0;
    long result = 0;
    unordered_map<long, int> cntMap;
    // 处理第一个窗口
    for (int i = 0; i < k; ++i)
    {
      cntMap[nums[i]] += 1;
      sum += nums[i];
    }
    if (cntMap.size() >= m)
    {
      result = max(result, sum);
    }
    // 处理后续窗口
    for (int i = k; i < nums.size(); i += 1)
    {
      sum += nums[i];
      sum -= nums[i - k];
      cntMap[nums[i]] += 1;
      cntMap[nums[i - k]] -= 1;
      if (cntMap[nums[i - k]] == 0)
        cntMap.erase(nums[i - k]);
      if (cntMap.size() >= m)
        result = max(result, sum);
    }
    return result;
  }
};
int main()
{
  vector<int> nums = {2, 6, 7, 3, 1, 7};
  int m = 3;
  int k = 4;
  Solution s;
  cout << s.maxSum(nums, m, k) << endl;
  nums = {5, 9, 9, 2, 4, 5, 4};
  m = 1;
  k = 3;
  cout << s.maxSum(nums, m, k) << endl;
  nums = {1, 2, 1, 2, 1, 2, 1};
  m = 3;
  k = 3;
  cout << s.maxSum(nums, m, k) << endl;
  nums = {1, 2, 3, 4, 5, 6, 7};
  m = 2;
  k = 3;
  cout << s.maxSum(nums, m, k) << endl;
  nums = {1, 1, 1, 2};
  m = 2;
  k = 2;
  cout << s.maxSum(nums, m, k) << endl;
  nums = {1, 1, 1, 2, 3};
  m = 2;
  k = 3;
  cout << s.maxSum(nums, m, k) << endl;
  return 0;
}